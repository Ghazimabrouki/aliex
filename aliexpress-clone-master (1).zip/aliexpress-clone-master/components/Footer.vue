<template>
    <div id="FooterMain" class="w-full bg-[#E8E8E8] mt-10 mb-2">
        <div class="max-w-[1200px] mx-auto px-4">

            <div class="md:flex gap-4 justify-between w-full">
                <div class="md:w-[50%] pt-4">
                    <div class="text-lg font-semibold text-[#282828]">Help</div>
                    <div class="text-[#999999] text-sm">Help Center, Disputes & Reports, Buyer Protection, Report IPR infringement, Regulated Information</div>
                </div>
                <div class="md:w-[50%] pt-4">
                    <div class="text-lg font-semibold text-[#282828]">AliExpress Multi-Language Sites</div>
                    <div class="text-[#999999] text-sm">Russian, Portuguese, Spanish, French, German, Italian, Dutch, Turkish, Japanese, Korean, Thai, Vietnamese, Arabic, Hebrew, Polish</div>
                </div>
            </div>

            <div class="md:flex gap-4 justify-between w-full">
                <div class="md:w-[50%] pt-4">
                    <div class="text-lg font-semibold text-[#282828]">Browse by Category</div>
                    <div class="text-[#999999] text-sm">All Popular, Product, Promotion, Low Price, Great Value, Reviews, Blog, Seller Portal, BLACK FRIDAY, AliExpress Assistant</div>
                </div>
                <div class="md:w-[50%] pt-4">
                    <div class="text-lg font-semibold text-[#282828]">Alibaba Group</div>
                    <div class="text-[#999999] text-sm">Alibaba Group Website, AliExpress, Alimama, Alipay, Fliggy, Alibaba Cloud, Alibaba International, AliTelecom, DingTalk, Juhuasuan, Taobao Marketplace, Tmall, Taobao Global, AliOS, 1688</div>
                </div>
            </div>

        </div>
    </div>

    <div id="FooterSub" class="w-full bg-[#333333] text-sm text-gray-400">
        <div class="max-w-[1200px] mx-auto p-4">
            Intellectual Property Protection - Privacy Policy - Sitemap - Terms of Use - Information for EU consumers - Transaction Services Agreement for non-EU/UK Consumers - Terms and Conditions for EU/EEA/UK Consumers (Transactions) - User Information Legal Enquiry Guide ©️2010-2022 AliExpress.com. All rights reserved.  增值电信业务经营许可证 浙B2-20120091-8  浙公网安备 33010802002248号
        </div>
    </div>
</template>

<script setup>

</script>
